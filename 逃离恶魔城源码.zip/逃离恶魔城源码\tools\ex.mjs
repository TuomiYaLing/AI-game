import fs from 'node:fs';
const pck = 'D:/EscapeFromDemonCastle/EscapeFromDemonCastle.pck';
const buf = fs.readFileSync(pck);
console.log('pck size', buf.length);

function findAll(needle) {
  const out = [];
  const n = Buffer.from(needle, 'utf8');
  let i = buf.indexOf(n);
  while (i >= 0) { out.push(i); i = buf.indexOf(n, i + 1); }
  return out;
}

const t = 'res://scripts/dungeon.gd';
const hits = findAll(t);
console.log('occurrences', hits.length, hits.slice(0, 6));
for (const idx of hits) {
  if (idx < 4) continue;
  const plen = buf.readUInt32LE(idx - 4);
  if (plen !== t.length) { console.log(' skip idx', idx, 'plen', plen); continue; }
  const nameEnd = idx + plen;
  if (nameEnd + 16 > buf.length) continue;
  const ofs = Number(buf.readBigUInt64LE(nameEnd));
  const size = Number(buf.readBigUInt64LE(nameEnd + 8));
  console.log(' VALID idx', idx, 'offset', ofs, 'size', size);
  if (size > 0 && size < 200000) {
    for (const delta of [0, 100, 104, 112, 96, 120]) {
      const start = ofs + delta;
      if (start + 8 > buf.length) continue;
      const head = buf.subarray(start, start + 8);
      const hex = head.toString('hex');
      if (head[0] === 0x47 && (head[1] === 0x44 || head[1] === 0x44)) {
        console.log('  HEAD@', start, hex, JSON.stringify(head.toString('utf8').replace(/[^\x20-\x7e]/g, '.')));
      }
    }
    // 直接看 offset 附近的字节
    console.log('  raw@ofs:', buf.subarray(ofs - 4, ofs + 24).toString('hex'));
  }
}
