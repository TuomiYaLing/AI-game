import fs from 'node:fs';
import path from 'node:path';

const dir = process.argv[2];
const files = fs.readdirSync(dir).filter(f => f.endsWith('.gd'));

function splitArgs(s) {
  let depth = 0, cur = '', out = [], inStr = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inStr) { cur += c; if (c === inStr) inStr = null; continue; }
    if (c === '"' || c === "'") { inStr = c; cur += c; continue; }
    if ('([{'.includes(c)) depth++;
    if (')]}'.includes(c)) depth--;
    if (c === ',' && depth === 0) { out.push(cur); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim() !== '') out.push(cur);
  return out;
}

let issues = 0;
for (const f of files) {
  const src = fs.readFileSync(path.join(dir, f), 'utf8');
  const defs = {};
  src.split('\n').forEach((ln, i) => {
    const m = ln.match(/^\s*(?:static\s+)?func\s+([A-Za-z_]\w*)\s*\((.*)\)/);
    if (!m) return;
    const params = splitArgs(m[2]);
    let min = 0, max = 0;
    for (const p of params) { if (p.trim() === '') continue; max++; if (p.includes('=')) continue; min++; }
    defs[m[1]] = { min, max, line: i + 1 };
  });
  for (let i = 0; i < src.length; i++) {
    const m = /^(?<![.\w])([A-Za-z_]\w*)\s*\(/.exec(src.slice(i));
    if (!m) continue;
    if (i > 0 && /[A-Za-z0-9_.]/.test(src[i - 1])) continue;
    const name = m[1];
    if (!defs[name]) continue;
    // 跳过定义行本身
    const lineStart = src.lastIndexOf('\n', i) + 1;
    const lineText = src.slice(lineStart, src.indexOf('\n', i) === -1 ? src.length : src.indexOf('\n', i));
    if (/^\s*(static\s+)?func\s/.test(lineText)) continue;
    let depth = 0, j = i + name.length, argsStr = '', inStr = null;
    for (; j < src.length; j++) {
      const c = src[j];
      if (inStr) { if (c === inStr) inStr = null; argsStr += c; continue; }
      if (c === '"' || c === "'") { inStr = c; argsStr += c; continue; }
      if (c === '(') { depth++; if (depth === 1) continue; }
      if (c === ')') { depth--; if (depth === 0) break; }
      argsStr += c;
    }
    const n = splitArgs(argsStr).length;
    const d = defs[name];
    const lineNo = src.slice(0, i).split('\n').length;
    if (n < d.min || n > d.max) {
      console.log(`${f}:${lineNo}  ${name}(${n}) 但定义在第 ${d.line} 行需要 ${d.min}~${d.max}`);
      issues++;
    }
    i = j;
  }
}
console.log(issues === 0 ? 'OK: 同文件调用参数个数匹配' : `共 ${issues} 处不匹配`);
