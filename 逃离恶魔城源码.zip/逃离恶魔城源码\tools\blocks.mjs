import fs from 'node:fs';

// 用缩进栈校验块结构：任何 dedent 必须回到栈中已有的层级
const dir = 'scripts';
const files = fs.readdirSync(dir).filter((f) => f.endsWith('.gd'));
let bad = 0;
for (const f of files) {
  const lines = fs.readFileSync(`${dir}/${f}`, 'utf8').split('\n');
  const stack = [0];
  let blockOpen = -1;
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i].replace(/\r$/, '');
    if (raw.trim() === '') continue;
    const code = raw.replace(/#.*$/, '').trimEnd();
    if (code.trim() === '') continue;
    let ind = 0;
    while (ind < raw.length && raw[ind] === '\t') ind++;
    const tabs = ind;
    if (tabs > stack[stack.length - 1]) {
      // 新块：上一行必须以 : 或括号结尾，否则报错
      const last = lines[blockOpen] !== undefined ? lines[blockOpen].trimEnd() : '';
      const okOpen = last.endsWith(':') || /[([{]$/.test(last) || last.endsWith(',') || /\sif\s.*else$/.test(last);
      if (!okOpen && blockOpen >= 0) {
        console.log(`${f}:${i + 1} 非法缩进加深（上一行 ${blockOpen + 1}: ${last.slice(0, 50)}）`);
        bad++;
      }
      stack.push(tabs);
    } else {
      while (stack.length > 1 && tabs < stack[stack.length - 1]) stack.pop();
      if (tabs !== stack[stack.length - 1]) {
        console.log(`${f}:${i + 1} 缩进层级不匹配（${tabs} tab）`);
        bad++;
      }
    }
    blockOpen = i;
  }
}
console.log(bad === 0 ? 'OK: 全部脚本块结构闭合正常' : `发现 ${bad} 处块结构问题`);
