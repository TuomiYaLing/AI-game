import fs from 'node:fs';
import path from 'node:path';

// 检查形如 <a>.<b>.<name> 的链式成员访问是否存在（只处理脚本常量对象）
const dir = process.argv[2];
const files = fs.readdirSync(dir).filter(f => f.endsWith('.gd'));
const srcs = {};
const members = {};
for (const f of files) {
  const s = fs.readFileSync(path.join(dir, f), 'utf8');
  srcs[f] = s;
  const set = new Set();
  for (const m of s.matchAll(/^(?:static\s+)?(?:var|const)\s+([A-Za-z_]\w*)/gm)) set.add(m[1]);
  for (const m of s.matchAll(/^(?:static\s+)?func\s+([A-Za-z_]\w*)/gm)) set.add(m[1]);
  members[f] = set;
}
// 对象变量名 -> 定义所在脚本
const OBJ = { game: 'main.gd', items: 'items.gd', skills: 'skills.gd', codex: 'codex.gd', W: 'weapons.gd', Art: 'art.gd' };
let bad = 0;
for (const f of files) {
  const src = srcs[f];
  for (const m of src.matchAll(/\b(game|items|skills|codex|W|Art)\.(game|items|skills|codex|W|Art)\.([A-Za-z_]\w*)/g)) {
    const mid = m[2], name = m[3];
    const def = members[OBJ[mid]];
    if (!def || !def.has(name)) {
      console.log(`MISSING ${m[1]}.${mid}.${name}  (${f})  -> 应存在于 ${OBJ[mid]}`);
      bad++;
    }
  }
}
console.log(bad === 0 ? 'OK: 二级成员访问全部存在' : `${bad} missing`);
