import fs from 'node:fs';
import path from 'node:path';

const dir = process.argv[2];
const files = fs.readdirSync(dir).filter(f => f.endsWith('.gd'));
let problems = 0;

function report(file, line, msg) {
  problems++;
  console.log(`${file}:${line}  ${msg}`);
}

for (const f of files) {
  const full = path.join(dir, f);
  const src = fs.readFileSync(full, 'utf8');
  const lines = src.split('\n');

  // 1) 行首只能用 tab 缩进
  lines.forEach((ln, i) => {
    const m = ln.match(/^[ \t]*/)[0];
    if (m.includes(' ')) report(f, i + 1, `行首出现空格缩进: "${ln.slice(0, 40)}"`);
  });

  // 2) 括号平衡（去掉字符串与注释）
  let depth = 0, line = 1, inStr = null;
  let clean = '';
  for (let i = 0; i < src.length; i++) {
    const c = src[i], n = src[i + 1];
    if (c === '\n') { line++; clean += '\n'; continue; }
    if (inStr) { if (c === '\\') { i++; continue; } if (c === inStr) inStr = null; clean += ' '; continue; }
    if (c === '#') { while (i < src.length && src[i] !== '\n') i++; line++; clean += '\n'; continue; }
    if (c === '"' || c === "'") { inStr = c; clean += ' '; continue; }
    if (c === '(' || c === '[' || c === '{') depth++;
    if (c === ')' || c === ']' || c === '}') depth--;
    if (depth < 0) { report(f, line, '圆括号/方括号/花括号提前闭合'); depth = 0; }
    clean += (c === '(' || c === ')' || c === '[' || c === ']' || c === '{' || c === '}') ? c : ' ';
  }
  if (depth !== 0) report(f, 0, `括号不平衡，剩余深度 ${depth}`);
  if (inStr) report(f, 0, '字符串未闭合');

  // 3) 块起始行（以 : 结尾）后面必须紧跟更深缩进的行
  const indentOf = (s) => s.match(/^\t*/)[0].length;
  for (let i = 0; i < lines.length - 1; i++) {
    const ln = lines[i].replace(/#.*$/, '').trimEnd();
    if (!ln.endsWith(':')) continue;
    if (/^\s*("|')/.test(ln)) continue; // 字典键值
    if (/\b(class_name|const|var)\b/.test(ln)) continue;
    // 找下一条非空行
    let j = i + 1;
    while (j < lines.length && lines[j].trim() === '') j++;
    if (j >= lines.length) { report(f, i + 1, '块起始行后没有内容'); continue; }
    if (indentOf(lines[j]) <= indentOf(lines[i])) {
      report(f, i + 1, `块起始行未缩进: "${lines[i].trim().slice(0, 50)}"`);
    }
  }

  // 4) 关键字行必须以 : 结尾
  lines.forEach((ln, i) => {
    const t = ln.trim();
    const code = t.replace(/#.*$/, '').trimEnd();
    if (/^(func|if|elif|else|for|while|match|class)\b/.test(code) && !code.endsWith(':')) {
      // 允许单行 if xxx: yyy 写法
      if (/^(if|elif)\b[^:]*:\s*\S/.test(code)) return;
      report(f, i + 1, `关键字行缺少冒号: "${t.slice(0, 50)}"`);
    }
    if (/^(func|for|while|match)\b[^:]*:/.test(code)) {
      // ok
    }
  });

  // 5) 重复函数名
  const seen = {};
  lines.forEach((ln, i) => {
    const m = ln.match(/^func\s+([A-Za-z_][A-Za-z0-9_]*)/);
    if (m) {
      if (seen[m[1]] !== undefined) report(f, i + 1, `重复定义函数 ${m[1]}（首次在第 ${seen[m[1]]} 行）`);
      seen[m[1]] = i + 1;
    }
  });

  // 6) 明显的分号/行尾多余空白
  lines.forEach((ln, i) => {
    if (/;\s*$/.test(ln)) report(f, i + 1, '行尾分号');
    if (/\t+$/.test(ln)) report(f, i + 1, '行尾制表符');
  });
  // 7) 缩进只能"上一行以 : 结尾时"加深（这条能抓到本次的 Parse Error）
  {
    let prev = null;
    for (let i = 0; i < lines.length; i++) {
      const raw = lines[i];
      if (raw.trim() === '') continue;
      const code = raw.replace(/#.*$/, '').trimEnd();
      const ind = indentOf(raw);
      if (prev !== null && ind > prev.ind) {
        const prevCode = prev.code;
        const contOpen = /[\(\[\{,]$/.test(prevCode) || /^\s*["']/.test(prevCode);
        if (!prevCode.endsWith(':') && !contOpen) {
          report(f, i + 1, `缩进非法加深（上一行第 ${prev.line} 行不是块起始）: "${raw.trim().slice(0, 40)}"`);
        }
      }
      prev = { ind, code, line: i + 1 };
    }
  }
}

console.log(problems === 0 ? 'OK: 未发现结构性问题' : `共发现 ${problems} 个问题`);
