﻿param(
    [Parameter(Position = 0)][string]$Path = '',
    [switch]$Editor,
    [switch]$KeepOpen
)

$ErrorActionPreference = 'Continue'
$project = Split-Path -Parent $PSScriptRoot
if (-not $project) { $project = (Get-Location).Path }
try { $Host.UI.RawUI.WindowTitle = '血月恶魔城 · 启动器' } catch { }

function Test-Exe([string]$p) {
    if ($p -and $p.Trim() -ne '' -and (Test-Path -LiteralPath $p)) {
        return (Get-Item -LiteralPath $p).FullName
    }
    return $null
}

function Find-Godot {
    $c = Test-Exe $Path
    if ($c) { return $c }
    foreach ($n in @('Godot.exe', 'godot.exe', 'Godot_v4.exe')) {
        $c = Test-Exe (Join-Path $project $n)
        if ($c) { return $c }
    }
    $f = Get-ChildItem -LiteralPath $project -Filter 'Godot*.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($f) { return $f.FullName }
    $c = Test-Exe $env:GODOT_BIN
    if ($c) { return $c }
    foreach ($n in @('godot.exe', 'godot4.exe')) {
        $cmd = Get-Command $n -ErrorAction SilentlyContinue
        if ($cmd) { return $cmd.Source }
    }
    $keys = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($k in $keys) {
        $items = Get-ItemProperty $k -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like '*Godot*' }
        foreach ($it in $items) {
            if ($it.InstallLocation -and (Test-Path -LiteralPath $it.InstallLocation)) {
                $g = Get-ChildItem -LiteralPath $it.InstallLocation -Filter 'Godot*.exe' -File -ErrorAction SilentlyContinue |
                     Where-Object { $_.Name -notmatch '(?i)console' } | Select-Object -First 1
                if ($g) { return $g.FullName }
            }
        }
    }
    $roots = @(
        "$env:LOCALAPPDATA\Programs",
        "$env:PROGRAMFILES",
        "${env:ProgramFiles(x86)}",
        "$env:LOCALAPPDATA\Microsoft\WinGet\Packages",
        "$env:USERPROFILE\Downloads",
        "$env:USERPROFILE\Desktop",
        'C:\Godot',
        'D:\Godot'
    )
    foreach ($r in $roots) {
        if (-not (Test-Path -LiteralPath $r)) { continue }
        $g = Get-ChildItem -LiteralPath $r -Filter 'Godot*.exe' -Recurse -Depth 3 -File -ErrorAction SilentlyContinue |
             Where-Object { $_.Name -notmatch '(?i)console' } | Select-Object -First 1
        if ($g) { return $g.FullName }
    }
    foreach ($d in @('C:\', 'D:\', 'E:\')) {
        if (-not (Test-Path -LiteralPath $d)) { continue }
        $g = Get-ChildItem -LiteralPath $d -Filter 'Godot*.exe' -Recurse -Depth 2 -File -ErrorAction SilentlyContinue |
             Where-Object { $_.Name -notmatch '(?i)console' } | Select-Object -First 1
        if ($g) { return $g.FullName }
    }
    return $null
}

$godot = Find-Godot

while (-not $godot) {
    Write-Host ''
    Write-Host '  =========================================================='
    Write-Host '    未 找 到  G O D O T   引 擎'
    Write-Host '  =========================================================='
    Write-Host '    本项目需要 Godot 4.2 或更新版本（标准版即可）'
    Write-Host ''
    Write-Host '    [1] 输入 / 拖入 Godot.exe 的完整路径'
    Write-Host '    [2] 用 winget 自动安装 Godot（需要联网）'
    Write-Host '    [3] 打开官网下载页'
    Write-Host '    [0] 退出'
    Write-Host ''
    $sel = Read-Host '  请选择'
    if ($null -eq $sel) { exit 1 }
    if ($sel -eq '1') {
        $p = Read-Host '  把 Godot.exe 拖到本行后回车'
        if ($p) {
            $p = $p.Trim()
            if ($p.StartsWith('"') -and $p.EndsWith('"')) { $p = $p.Substring(1, $p.Length - 2) }
            if (Test-Path -LiteralPath $p) {
                $godot = (Get-Item -LiteralPath $p).FullName
            } else {
                Write-Host '  路径无效，请重试。'
            }
        }
    } elseif ($sel -eq '2') {
        if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
            Write-Host '  未检测到 winget，请手动下载安装。'
        } else {
            Write-Host '  正在安装 Godot（首次下载约 60MB）...'
            & winget install --id GodotEngine.Godot -e --accept-package-agreements --accept-source-agreements
            $godot = Find-Godot
            if ($godot) { Write-Host ('  安装成功：' + $godot) }
            else { Write-Host '  安装似乎没有成功，请手动下载。' }
        }
    } elseif ($sel -eq '3') {
        Start-Process 'https://godotengine.org/download/windows/'
        Write-Host '  已在浏览器打开下载页，装好后重新运行本文件。'
    } elseif ($sel -eq '0' -or $sel -eq '') {
        exit 1
    }
}

Write-Host ''
Write-Host '  =========================================================='
Write-Host '    血 月 恶 魔 城   ·   B L O O D   M O O N   C A S T L E'
Write-Host '  =========================================================='
Write-Host ('    引擎 : ' + $godot)
Write-Host ('    项目 : ' + $project)
Write-Host '  =========================================================='

$verTxt = ''
try { $verTxt = (& $godot --version 2>$null | Out-String).Trim() } catch { $verTxt = '' }
if ($verTxt -match '^(\d+)\.(\d+)') {
    $vMaj = [int]$Matches[1]
    $vMin = [int]$Matches[2]
    if ($vMaj -lt 4 -or ($vMaj -eq 4 -and $vMin -lt 2)) {
        Write-Host ''
        Write-Host ('  [!] 检测到 Godot ' + $vMaj + '.' + $vMin + '，本项目需要 Godot 4.2 或更新版本。')
        Write-Host '      下载地址：https://godotengine.org/download/windows/'
        Write-Host ''
        Read-Host '  按回车退出'
        exit 1
    }
}

if ($Editor) {
    Write-Host '    正在打开 Godot 编辑器...'
    Start-Process -FilePath $godot -ArgumentList ('--editor --path "' + $project + '"')
    Start-Sleep -Milliseconds 400
    exit 0
}

$imported = Test-Path -LiteralPath (Join-Path $project '.godot')
if ($imported -and -not $KeepOpen) {
    Write-Host '    正在启动游戏...'
    Start-Process -FilePath $godot -ArgumentList ('--path "' + $project + '"')
    Start-Sleep -Milliseconds 400
    exit 0
}

Write-Host ''
Write-Host '    首次运行：正在导入资源并启动，可能需要几十秒...'
Write-Host '    这个窗口会一直显示引擎日志，游戏退出后按回车关闭。'
Write-Host ''
& $godot --path $project
Write-Host ''
Write-Host '  [ 游戏进程已退出 ]'
Write-Host '  如果上面出现红色 SCRIPT ERROR / Parse Error，请把内容复制反馈。'
Write-Host '  提示：想强制保留日志窗口，可用  启动游戏.bat -KeepOpen  启动。'
Read-Host '  按回车关闭'
exit 0