Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class ResUpd {
    [DllImport("kernel32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
    public static extern IntPtr BeginUpdateResource(string pFileName, bool bDeleteExistingResources);
    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool UpdateResource(IntPtr hUpdate, IntPtr lpType, IntPtr lpName, ushort wLanguage, byte[] lpData, uint cbData);
    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool EndUpdateResource(IntPtr hUpdate, bool fDiscard);
}
"@

$exe = "D:\gerter\build\EscapeFromDemonCastle.exe"
$exe = $args[0]
$manifest = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity version="1.0.0.0" processorArchitecture="*" name="EscapeFromDemonCastle" type="win32"/>
  <description>Escape from the Demon Castle</description>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3">
    <security>
      <requestedPrivileges>
        <requestedExecutionLevel level="asInvoker" uiAccess="false"/>
      </requestedPrivileges>
    </security>
  </trustInfo>
  <compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1">
    <application>
      <supportedOS Id="{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}"/>
      <supportedOS Id="{1f676c76-80e1-4239-95bb-83d0f6d0da78}"/>
    </application>
  </compatibility>
  <application xmlns="urn:schemas-microsoft-com:asm.v3">
    <windowsSettings>
      <dpiAware xmlns="http://schemas.microsoft.com/SMI/2005/WindowsSettings">true</dpiAware>
      <longPathAware xmlns="http://schemas.microsoft.com/SMI/2016/WindowsSettings">true</longPathAware>
    </windowsSettings>
  </application>
</assembly>
'@

$bytes = [System.Text.Encoding]::UTF8.GetBytes($manifest)
$h = [ResUpd]::BeginUpdateResource($exe, $false)
if ($h -eq [IntPtr]::Zero) {
    Write-Output ("BEGIN_FAIL " + [System.Runtime.InteropServices.Marshal]::GetLastWin32Error())
    exit 1
}
$ok = [ResUpd]::UpdateResource($h, [IntPtr]24, [IntPtr]1, 0, $bytes, [uint32]$bytes.Length)
if (-not $ok) { Write-Output ("UPDATE_FAIL " + [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()) }
$done = [ResUpd]::EndUpdateResource($h, $false)
if (-not $done) { Write-Output ("END_FAIL " + [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()) } else { Write-Output "MANIFEST_OK" }
