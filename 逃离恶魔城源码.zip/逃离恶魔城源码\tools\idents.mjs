import fs from 'node:fs';
import path from 'node:path';

const dir = process.argv[2];
const files = fs.readdirSync(dir).filter(f => f.endsWith('.gd'));

const KW = new Set(('var func if elif else for in while return match pass and or not true false null ' +
  'class_name extends const static signal break continue self PI TAU preload void').split(' '));

const BUILTIN = new Set((
  // 类型
  'Color Vector2 Vector2i Rect2 Rect2i Image ImageTexture Gradient GradientTexture2D SystemFont ' +
  'AudioStreamWAV AudioStreamPlayer Sprite2D CanvasItemMaterial Camera2D CanvasLayer Control Node2D Node ' +
  'RandomNumberGenerator PackedStringArray PackedByteArray PackedFloat32Array PackedVector2Array PackedColorArray ' +
  'Input InputEventKey InputEventMouseButton InputMap Key MouseButton ' +
  // 常量
  'KEY_A KEY_D KEY_S KEY_W KEY_Q KEY_E KEY_J KEY_K KEY_L KEY_V KEY_N KEY_R KEY_UP KEY_DOWN KEY_LEFT KEY_RIGHT ' +
  'KEY_SPACE KEY_SHIFT KEY_CTRL KEY_ESCAPE ' +
  'MOUSE_BUTTON_LEFT MOUSE_BUTTON_RIGHT MOUSE_BUTTON_MIDDLE ' +
  'HORIZONTAL_ALIGNMENT_LEFT HORIZONTAL_ALIGNMENT_CENTER ' +
  // 全局函数
  'abs absf ceil clamp clampf clampi cos deg_to_rad exp float fmod fposmod int lerp lerpf log max maxf maxi min minf mini ' +
  'move_toward pow rad_to_deg randf randf_range randi randi_range randomize range round roundf sign signf sin snapped snappedf sqrt str tan typeof ' +
  'is_instance_valid preload load print print_line push_error push_warning e').split(' '));

for (const f of files) {
  const src = fs.readFileSync(path.join(dir, f), 'utf8').split('\n');
  // 本文件声明的名字
  const local = new Set();
  const add = (n) => { if (n) local.add(n); };
  for (const line of src) {
    const code = line.replace(/#.*$/, '');
    let m;
    if ((m = code.match(/^\s*(?:static\s+)?(?:var|const)\s+([A-Za-z_]\w*)/))) add(m[1]);
    if ((m = code.match(/^\s*(?:static\s+)?func\s+([A-Za-z_]\w*)/))) add(m[1]);
    if ((m = code.match(/^\s*signal\s+([A-Za-z_]\w*)/))) add(m[1]);
    if ((m = code.match(/^\s*enum\s+([A-Za-z_]\w*)/))) add(m[1]);
    // 参数
    const fm = code.match(/^\s*(?:static\s+)?func\s+\w+\s*\((.*)\)/);
    if (fm) {
      for (const p of fm[1].split(',')) {
        const pm = p.match(/^\s*([A-Za-z_]\w*)/);
        if (pm) add(pm[1]);
      }
    }
    // for 变量
    const fv = code.match(/^\s*for\s+([A-Za-z_]\w*)/);
    if (fv) add(fv[1]);
    // 局部 var（含缩进）
    const lv = code.match(/^\s+var\s+([A-Za-z_]\w*)/);
    if (lv) add(lv[1]);
  }
  const unknown = new Map();
  src.forEach((line, idx) => {
    // 去掉字符串与注释
    const code = line.replace(/#.*$/, '').replace(/"[^"]*"/g, '""').replace(/'[^']*'/g, "''");
    for (const m of code.matchAll(/(?<![.\w])[A-Za-z_]\w*/g)) {
      const id = m[0];
      if (KW.has(id) || BUILTIN.has(id) || local.has(id)) continue;
      // 字符串方法调用等跳过：形如  x.method( 里的 method 前面有 .
      if (!unknown.has(id)) unknown.set(id, idx + 1);
    }
  });
  if (unknown.size) {
    console.log(`--- ${f}`);
    for (const [id, ln] of unknown) console.log(`   ${id}   (行 ${ln})`);
  }
}
