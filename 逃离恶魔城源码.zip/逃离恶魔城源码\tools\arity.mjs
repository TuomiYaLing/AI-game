import fs from 'node:fs';
import path from 'node:path';

const dir = process.argv[2];
const files = fs.readdirSync(dir).filter(f => f.endsWith('.gd'));
const defs = {};  // 'file.gd::name' -> {min,max,line}
const srcs = {};

function splitArgs(s) {
  let depth = 0, cur = '', out = [];
  let inStr = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inStr) { cur += c; if (c === inStr && s[i - 1] !== '\\') inStr = null; continue; }
    if (c === '"' || c === "'") { inStr = c; cur += c; continue; }
    if ('([{'.includes(c)) depth++;
    if (')]}'.includes(c)) depth--;
    if (c === ',' && depth === 0) { out.push(cur); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim() !== '') out.push(cur);
  return out;
}

for (const f of files) {
  const src = fs.readFileSync(path.join(dir, f), 'utf8');
  srcs[f] = src;
  const lines = src.split('\n');
  lines.forEach((ln, i) => {
    const m = ln.match(/^\s*(?:static\s+)?func\s+([A-Za-z_]\w*)\s*\((.*)\)/);
    if (!m) return;
    const params = splitArgs(m[2]);
    let min = 0, max = 0;
    for (const p of params) {
      if (p.trim() === '') continue;
      max++;
      if (p.includes('=')) continue;
      min++;
    }
    defs[`${f}::${m[1]}`] = { min, max, line: i + 1 };
  });
}

const TARGET = { Art: 'art.gd', game: 'main.gd', player: 'player.gd', dungeon: 'dungeon.gd', level: 'dungeon.gd', fx: 'fx.gd', sfx: 'sfx.gd', hud: 'hud.gd' };
let issues = 0;
for (const f of files) {
  const src = srcs[f];
  // 多行调用先合并（简单处理：按字符流扫描 <target>.<name>(
  for (let i = 0; i < src.length; i++) {
    const m = /^(Art|game|player|dungeon|level|fx|sfx|hud)\.([A-Za-z_]\w*)\s*\(/.exec(src.slice(i));
    if (!m) continue;
    if (i > 0 && /[A-Za-z0-9_.]/.test(src[i - 1])) continue;
    const key = `${TARGET[m[1]]}::${m[2]}`;
    let depth = 0, j = i + m[0].length - 1, argsStr = '';
    let inStr = null;
    for (; j < src.length; j++) {
      const c = src[j];
      if (inStr) { if (c === inStr) inStr = null; argsStr += c; continue; }
      if (c === '"' || c === "'") { inStr = c; argsStr += c; continue; }
      if (c === '(') { depth++; if (depth === 1) continue; }
      if (c === ')') { depth--; if (depth === 0) break; }
      argsStr += c;
    }
    const n = splitArgs(argsStr).length;
    const d = defs[key];
    const lineNo = src.slice(0, i).split('\n').length;
    if (!d) continue;
    if (n < d.min || n > d.max) {
      console.log(`${f}:${lineNo}  ${m[1]}.${m[2]}(${n} 个参数) 但定义 ${key}:${d.line} 需要 ${d.min}~${d.max}`);
      issues++;
    }
    i = j;
  }
}
console.log(issues === 0 ? 'OK: 跨脚本调用参数个数匹配' : `共 ${issues} 处参数数量不匹配`);
