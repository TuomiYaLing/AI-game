import fs from 'node:fs';
import zlib from 'node:zlib';

// --- 极简 PNG 解码（8bit, colorType 2/6, 非隔行）---
function decodePNG(file) {
  const buf = fs.readFileSync(file);
  let pos = 8;
  let w = 0, h = 0, colorType = 6, bitDepth = 8;
  const idat = [];
  while (pos < buf.length) {
    const len = buf.readUInt32BE(pos); pos += 4;
    const type = buf.toString('ascii', pos, pos + 4); pos += 4;
    const data = buf.subarray(pos, pos + len); pos += len + 4;
    if (type === 'IHDR') {
      w = data.readUInt32BE(0); h = data.readUInt32BE(4);
      bitDepth = data[8]; colorType = data[9];
      if (data[12] !== 0) throw new Error('interlaced not supported');
    } else if (type === 'IDAT') idat.push(data);
    else if (type === 'IEND') break;
  }
  if (bitDepth !== 8) throw new Error('bit depth ' + bitDepth);
  const bpp = colorType === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = w * bpp;
  const out = Buffer.alloc(w * h * 3);
  let prev = Buffer.alloc(stride);
  for (let y = 0; y < h; y++) {
    const f = raw[y * (stride + 1)];
    const line = Buffer.from(raw.subarray(y * (stride + 1) + 1, y * (stride + 1) + 1 + stride));
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? line[x - bpp] : 0;
      const b = prev[x];
      const c = x >= bpp ? prev[x - bpp] : 0;
      let v = line[x];
      if (f === 1) v = (v + a) & 255;
      else if (f === 2) v = (v + b) & 255;
      else if (f === 3) v = (v + ((a + b) >> 1)) & 255;
      else if (f === 4) {
        const p = a + b - c;
        const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
      }
      line[x] = v;
    }
    for (let x = 0; x < w; x++) {
      if (bpp === 4) { out[(y * w + x) * 3] = line[x * 4]; out[(y * w + x) * 3 + 1] = line[x * 4 + 1]; out[(y * w + x) * 3 + 2] = line[x * 4 + 2]; }
      else { out[(y * w + x) * 3] = line[x * 3]; out[(y * w + x) * 3 + 1] = line[x * 3 + 1]; out[(y * w + x) * 3 + 2] = line[x * 3 + 2]; }
    }
    prev = line;
  }
  return { w, h, data: out };
}

const img = decodePNG(process.argv[2]);
const px = (x, y) => {
  const i = (y * img.w + x) * 3;
  return [img.data[i], img.data[i + 1], img.data[i + 2]];
};
const lum = (c) => 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];

const ramp = ' .:-=+*oO#%@';
function ascii(x0, y0, x1, y1, cw = 2, chh = 4) {
  const rows = [];
  for (let y = y0; y < y1; y += chh) {
    let line = '';
    for (let x = x0; x < x1; x += cw) {
      let s = 0, n = 0, mx = 0;
      for (let yy = y; yy < Math.min(y + chh, y1); yy++)
        for (let xx = x; xx < Math.min(x + cw, x1); xx++) {
          const l = lum(px(xx, yy)); s += l; n++; mx = Math.max(mx, l);
        }
      const v = (s / n) * 0.35 + mx * 0.65;
      let idx = Math.min(ramp.length - 1, Math.floor((v / 255) * ramp.length * 2.2));
      line += ramp[idx];
    }
    rows.push(line);
  }
  return rows.join('\n');
}

const args = process.argv.slice(3).map(Number);
console.log(`image ${img.w}x${img.h}`);
if (args.length >= 4) {
  console.log(ascii(args[0], args[1], args[2], args[3]));
} else {
  console.log(ascii(0, 0, img.w, img.h, 8, 16));
}
