import fs from 'node:fs';
import path from 'node:path';

const dir = process.argv[2];
const files = fs.readdirSync(dir).filter(f => f.endsWith('.gd'));
const members = {};   // file -> Set of names
const srcs = {};

for (const f of files) {
  const src = fs.readFileSync(path.join(dir, f), 'utf8');
  srcs[f] = src;
  const set = new Set();
  for (const m of src.matchAll(/^(?:static\s+)?(?:var|const)\s+([A-Za-z_][A-Za-z0-9_]*)/gm)) set.add(m[1]);
  for (const m of src.matchAll(/^(?:static\s+)?func\s+([A-Za-z_][A-Za-z0-9_]*)/gm)) set.add(m[1]);
  for (const m of src.matchAll(/^signal\s+([A-Za-z_][A-Za-z0-9_]*)/gm)) set.add(m[1]);
  members[f] = set;
}

const targets = {
  game: 'main.gd', player: 'player.gd', dungeon: 'dungeon.gd',
  level: 'dungeon.gd', fx: 'fx.gd', sfx: 'sfx.gd', hud: 'hud.gd',
  items: 'items.gd', skills: 'skills.gd', W: 'weapons.gd', Art: 'art.gd',
};
const INHERITED = new Set(['position', 'global_position', 'name', 'queue_free', 'queue_redraw',
  'modulate', 'rotation', 'scale', 'z_index', 'texture_filter', 'size', 'visible', 'material',
  'add_child', 'get_child_count', 'move_child', 'is_instance_valid', 'get_instance_id', 'gd']);

let bad = 0;
for (const f of files) {
  const src = srcs[f];
  for (const m of src.matchAll(/\b(game|player|dungeon|level|fx|sfx|hud|items|skills|W|Art)\.([A-Za-z_][A-Za-z0-9_]*)/g)) {
    const tgt = targets[m[1]];
    const name = m[2];
    if (INHERITED.has(name)) continue;
    if (name === 'gd') continue;
    if (!members[tgt].has(name)) {
      console.log(`MISSING ${m[1]}.${name}  (used in ${f})  -> should exist in ${tgt}`);
      bad++;
    }
  }
}
console.log(bad === 0 ? 'OK: all cross-file members exist' : `${bad} missing`);
