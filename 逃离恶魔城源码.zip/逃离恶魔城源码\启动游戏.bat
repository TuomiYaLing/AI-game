@echo off
where powershell >nul 2>nul
if errorlevel 1 (
	echo [ERROR] PowerShell not found. Open this folder with Godot 4.2+ manually.
	pause
	exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\launch.ps1" %*