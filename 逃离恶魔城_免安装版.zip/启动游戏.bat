@echo off
rem launch as normal user (no admin required)
cd /d "%~dp0"
start "" "EscapeFromDemonCastle.exe"
exit
