@echo off
cd /d "%~dp0"
start "" "EscapeFromDemonCastle.exe"
exit
